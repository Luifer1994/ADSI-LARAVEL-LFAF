<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Estudiantes extends Model
{
    public $timestamps=false;
}
