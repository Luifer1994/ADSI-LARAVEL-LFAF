<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ApoyosAcademicos extends Model
{
    //
}
