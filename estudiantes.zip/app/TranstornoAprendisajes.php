<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TranstornoAprendisajes extends Model
{
    //
}
