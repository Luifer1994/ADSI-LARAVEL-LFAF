<?php

namespace App\Exports;

use App\Estudiantes;
use Maatwebsite\Excel\Concerns\FromCollection;

class EstudiantesExport implements FromCollection
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        return Estudiantes::join("grados", "grados.id", "=", "estudiantes.id_grado")
        ->join("jornadas", "jornadas.id", "=", "estudiantes.id_jornada")
        ->join("sedes", "sedes.id", "=", "estudiantes.id_sede")
        ->join("paises as paisEs", "paisEs.id", "=", "estudiantes.id_pais")
        ->join("tipos_de_documentos as tipodocumentEs", "tipodocumentEs.id", "=", "estudiantes.id_tipoDocumento")
        ->join("generos as generoEs", "generoEs.id", "=", "estudiantes.id_genero")
        ->join("municipios as muniExp", "muniExp.id", "=", "estudiantes.id_municipioExp")
        ->join("departamentos as departExp", "departExp.id", "=", "estudiantes.id_departamentoExp")
        ->join("municipios as muniNac", "muniNac.id", "=", "estudiantes.id_municipioNac")
        ->join("departamentos as departNac", "departNac.id", "=", "estudiantes.id_departamentoNac")
        ->join("municipios as muniViv", "muniViv.id", "=", "estudiantes.id_municipioViv")
        ->join("zonas as zonaEs", "zonaEs.id", "=", "estudiantes.id_zona")
        ->join("tipos_de_sangres", "tipos_de_sangres.id", "=", "estudiantes.id_tipoSangre")
        ->join("poblaciones_victimas", "poblaciones_victimas.id", "=", "estudiantes.id_poblacionVictima")
        ->join("estratos", "estratos.id", "=", "estudiantes.id_estrato")
        // ->join("situaciones_socioeconomicas", "situaciones_socioeconomicas.id", "=", "estudiantes.id_situacionSocioeconomica")
        // ->join("etnias", "etnias.id", "=", "estudiantes.id_etnia")
        // ->join("discapacidades", "discapacidades.id", "=", "estudiantes.id_discapacidad")
        // ->join("transtorno_aprendisajes", "transtorno_aprendisajes.id", "=", "estudiantes.id_trasntornoAprend")
        // ->join("apoyos_academicos", "apoyos_academicos.id", "=", "estudiantes.id_apoyoAcademico")
        // ->join("capacidades_exepcionales", "capacidades_exepcionales.id", "=", "estudiantes.id_capacidadExepcional")
        // ->join("paises as paisAcu", "paisAcu.id", "=", "estudiantes.id_paisAcud")
        // ->join("parentescos", "parentescos.id", "=", "estudiantes.id_parentesco")
        // ->join("zonas as zonaAcu", "zonaAcu.id", "=", "estudiantes.id_zonaAcud")
        // ->join("tipos_de_documentos as tipodocumentAcu", "tipodocumentAcu.id", "=", "estudiantes.id_tipoDocumentoAcud")
        // ->join("generos as generoAcu", "generoAcu.id", "=", "estudiantes.id_generoAcud")
        // ->join("departamentos as departAcu", "departAcu.id", "=", "estudiantes.id_departamentoAcud")
        // ->join("departamentos as departNacAcu", "departNacAcu.id", "=", "estudiantes.id_departamentoNacAcud")
        // ->join("municipios as muniAcu", "muniAcu.id", "=", "estudiantes.id_municipioAcud")
        // ->join("municipios as muniNacAcu", "muniNacAcu.id", "=", "estudiantes.id_municipioNacAcud")
        // ->join("tipos_de_empleos", "tipos_de_empleos.id", "=", "estudiantes.id_tipoEmpleo")

        ->select("fechaInscripcion", "grados.grado", "jornadas.jornada", "sedes.sede", "paisEs.pais",
                    "tipodocumentEs.tipoDocumento", "numeroDocumento", "generoEs.genero", "muniExp.municipio",
                    "departExp.departamento", "fechaNacimiento", "muniNac.municipio", "departNac.departamento",
                    "apellidos", "nombres", "direccion", "barrio","muniViv.municipio", "zonaEs.zona",
                    "celular", "correo", "sectorPrivado", "provieneDeOtroMunicipio", "institucionDeDondeProviene",
                    "eps", "ips", "tipos_de_sangres.tipoSangre", "poblaciones_victimas.poblacion", "numeroCarnetSisben",
                    "puntajeSisben", "estratos.estrato", "nombreAcudiente", "apellidoAcudiente", "direccionAcud",
                    "barrioAcud", "celularAcud", "correoAcud", "numeroDocumentoAcud", "ocupacion", "profesion")
        ->get();
        // "fechaInscripcion", "grados.grado", "jornadas.jornada", "sedes.sede", "paisEs.pais",
        //             "tipodocumentEs.tipoDocumento", "numeroDocumento", "generoEs.genero", "muniExp.municipio",
        //             "departExp.departamento", "fechaNacimiento", "muniNac.municipio", "departNac.departamento",
        //             "apellidos", "nombres", "direccion", "barrio", "muniViv.municipio", "zonaEs.zona",
        //             "celular", "correo", "sectorPrivado", "provieneDeOtroMunicipio", "institucionDeDondeProviene",
        //             "eps", "ips", "tipos_de_sangres.tipoSangre", "poblaciones_victimas.poblacion", "numeroCarnetSisben",
        //             "puntajeSisben", "estratos.estrato", "situaciones_socioeconomicas.situacionSocioeconomica",
        //             "etnias.etnia", "discapacidades.discapacidad"
    }
}
