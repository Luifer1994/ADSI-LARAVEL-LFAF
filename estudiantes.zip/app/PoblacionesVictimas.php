<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PoblacionesVictimas extends Model
{
    //
}
