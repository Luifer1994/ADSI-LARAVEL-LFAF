<?php $__env->startSection('content'); ?>
    <hr>
    
    <div class="container" style="text-align: center">
       <img style="height: 150px; width: 115px" src=" <?php echo e(asset('/images/colegio.jpg')); ?>"  alt="">
       <h5>INSTITUCION EDUCATIVA NUESTRA SEÑORA DEL CAMEN</h5>
       <hr>
        <h4>INSCRIPCION NUEVO ESTUDIANTE </h4>
    </div>
    
    <?php if(session('mensaje2')): ?>
    <div class="alert alert-danger text-center" id="alert" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        <h4><?php echo e(session ('mensaje2')); ?></h4>
    </div>
   <?php endif; ?>

     
     <?php if(session('mensaje')): ?>
     <div class="alert alert-primary text-center" id="alert" role="alert">
         <button type="button" class="close" data-dismiss="alert" aria-label="Close">
             <span aria-hidden="true">&times;</span>
           </button>
         <h4><?php echo e(session ('mensaje')); ?></h4>
     </div>
    <?php endif; ?>

    
    <div class="progress">
     <div class="progress-bar progress-bar-striped bg-warning" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="color: black"></div>
    </div>

    
    <?php if($errors->any()): ?>
    <div class="alert alert-danger text-sm-center" id="alert" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
       <h4>ERROR AL REGISTAR, HAY CAMPOS VACIOS REVISA EL FORMULARIO</h4>
      </div>
      <?php endif; ?>


     
    <form id="regiration_form" novalidate action="<?php echo e(route('store')); ?>"  method="post">
        <?php echo csrf_field(); ?>
        <fieldset>
        <div class="container" style="background-color: #C0F9DE; text-align: center; border-radius: 50px 50px 50px 50px">
        <h5>DATOS PRINCIPALES </h5>
        </div>
        <hr>

        <div class="form-row">
            <div class="col-md-6 mb-3">
                <label for="tipoDocumento">TIPO DE DOCUMENTO</label>
                <select class="form-control"  id="tipoDocumento" name="tipoDocumento" required>
                <option value="">Seleccione...</option>
                <?php $__currentLoopData = $tipoDocumento; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipoDocumento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($tipoDocumento->id); ?>"  <?php echo e(old('tipoDocumento') ==  $tipoDocumento->id  ? 'selected' : ''); ?>>
                    <?php echo e($tipoDocumento->tipoDocumento); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-6 mb-3">
                <label for="numeroDocumento">NUMERO DE DOCUMENTO</label>
                <input type="text" class="form-control" id="numeroDocumento" name="numeroDocumento" value="<?php echo e(old('numeroDocumento')); ?>" placeholder="Ingresa Tu Numero de Documento">
            </div>
        </div>

        <div class="form-row">
            <div class="col-md-6 mb-3">
                <label for="departamentoExp">DEPARTAMENTO DE EXPEDICION</label>
                <select class="form-control"  id="departamentoExp" name="departamentoExp" required>
                    <option value="">Seleccione...</option>
                    <?php $__currentLoopData = $departamentoExp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departamentoExp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($departamentoExp->id); ?>"  <?php echo e(old('departamentoExp') ==  $departamentoExp->id  ? 'selected' : ''); ?>>
                        <?php echo e($departamentoExp->departamento); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-6 mb-3">
                <label for="municipioExp">MUNICIPIO DE EXPEDICION</label>
                <select class="form-control"  id="municipioExp" name="municipioExp" required>
                    <option value="">Seleccione...</option>
                    <?php $__currentLoopData = $municipioExp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $municipioExp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($municipioExp->id); ?>" <?php echo e(old('municipioExp') == $municipioExp->id ? 'selected' : ''); ?>>
                        <?php echo e($municipioExp->municipio); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <div class="form-row">
            <div class="col-md-6 mb-3">
                <label for="nombres">NOMBRES</label>
                <input type="text" class="form-control" value="<?php echo e(old('nombres')); ?>" id="nombres" name="nombres" placeholder="Ingresa tus Nombres" required>
            </div>
            <div class="col-md-6 mb-3">
            <label for="apellidos">APELLIDOS</label>
            <input type="text" class="form-control" value="<?php echo e(old('apellidos')); ?>" id="apellidos" name="apellidos" placeholder="Ingresa tus Apellidos" required>
            </div>
        </div>

        <div class="form-row">
            <div class="col-md-6 mb-3">
                <label for="fechaN">FECHA DE NACIMIENTO</label>
                <input type="date" class="form-control" value="<?php echo e(old('fechaN')); ?>" id="fechaN" name="fechaN" required>
            </div>
            <div class="col-md-6 mb-3">
                <label for="municipioN">MUNICIPIO DE NACIMIENTO</label>
                <select name="municipioN" id="municipioN" class="form-control">
                    <option value="">Seleccione...</option>
                    <?php $__currentLoopData = $municipioN; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $municipioN): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($municipioN->id); ?>" <?php echo e(old('municipioN') == $municipioN->id ? 'selected' : ''); ?>>
                            <?php echo e($municipioN->municipio); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="form-row">
            <div class="col-md-6 mb-3">
                <label for="departamentoN">DEPARTAMENTO DE NACIMIENTO</label>
                <select name="departamentoN" id="departamentoN" class="form-control">
                    <option value="">Seleccione...</option>
                    <?php $__currentLoopData = $departamentoN; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departamentoN): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($departamentoN->id); ?>"><?php echo e($departamentoN->departamento); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div
        <hr>
        <div class="form-row">
            <div class="col-md-6 mb-3">
                <label for="celular">CELULAR</label>
                <input type="text" class="form-control" value="<?php echo e(old('celular')); ?>" id="celular" name="celular" placeholder="Ingresa tu Numero de Celular" required>
            </div>
            <div class="col-md-6 mb-3">
            <label for="correo">CORREO</label>
            <input type="email" class="form-control" value="<?php echo e(old('correo')); ?>" id="correo" name="correo" placeholder="Ingresa tu Correo" required>
            </div>
        </div>
            <br>
            <div class="container text-center"  style="background-color: #C0F9DE; text-align: center; border-radius: 50px 50px 50px 50px">
            <h5>DIRECCION DEL ESTUDIANTE</h5>
            </div>
            <hr>
        <div class="form-row">
            <div class="col-md-6 mb-3">
                <label for="direccion">DIRECCION</label>
                <input type="text" class="form-control" value="<?php echo e(old('direccion')); ?>" id="direccion" name="direccion" placeholder="Ingresa tu Direccion" required>
            </div>
            <div class="col-md-6 mb-3">
            <label for="barrio">BARRIO</label>
            <input type="text" class="form-control" value="<?php echo e(old('barrio')); ?>" id="barrio" name="barrio" placeholder="Ingresa tu Barrio" required>
            </div>
        </div>

        <div class="form-row">
            <div class="col-md-6 mb-3">
                <label for="municipioViv'">MUNICIPIO </label>
                <select class="form-control"  id="municipioViv" name="municipioViv" required>
                    <option value="">Seleccione...</option>
                    <?php $__currentLoopData = $municipioViv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $municipioViv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($municipioViv->id); ?>" <?php echo e(old('municipioViv')==$municipioViv->id ? 'selected' : ''); ?>>
                        <?php echo e($municipioViv->municipio); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-6 mb-3">
                <label for="zona">ZONA </label>
                <select class="form-control"  id="zona" name="zona" required>
                    <option value="">Seleccione...</option>
                    <?php $__currentLoopData = $zona; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($zona->id); ?>" <?php echo e(old('zona')==$zona->id ? 'selected' : ''); ?>>
                        <?php echo e($zona->zona); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="form-row">
            <div class="col-md-6 mb-3">
                <label for="genero">GENERO</label>
                    <select class="form-control"  id="genero" name="genero" required>
                        <option value="">Seleccione...</option>
                        <?php $__currentLoopData = $genero; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($genero->id); ?>"<?php echo e(old('genero')==$genero->id ? 'selected' : ''); ?>><?php echo e($genero->genero); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
            </div>
            <div class="col-md-6 mb-3">
                <label for="fechaIns">FECHA INSCRIPCION</label>
                <input class="form-control"  type="date" id="fechaIns" name="fechaIns"  value="<?php echo  date("Y-m-d");?>">
            </div>
        </div>
        <div class="form-row">
            <div class="col-md-6 mb-3">
                <label for="grado">GRADO A CURSAR</label>
                <select class="form-control"  id="grado" name="grado" required>
                    <option value="">Seleccione...</option>
                    <?php $__currentLoopData = $grado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($grado->id); ?>" <?php echo e(old('grado')==$grado->id ? 'selected' : ''); ?>>
                            <?php echo e($grado->grado); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-6 mb-3">
                <label for="sede">SEDE</label>
                <select class="form-control"  id="sede" name="sede" required>
                    <option value="">Seleccione...</option>
                    <?php $__currentLoopData = $sede; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sede): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($sede->id); ?>" <?php echo e(old('sede')==$sede->id ? 'selected' : ''); ?>>
                            <?php echo e($sede->sede); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="form-row">
            <div class="col-md-6 mb-3">
                <label for="jornada">JORNADA</label>
                <select class="form-control"  id="jornada" name="jornada" required>
                    <option value="">Seleccione...</option>
                    <?php $__currentLoopData = $jornada; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jornada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($jornada->id); ?>" <?php echo e(old('jornada')==$jornada->id ? 'selected' : ''); ?>>
                            <?php echo e($jornada->jornada); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-6 mb-3">
                <label for="pais">PAIS DE ORIGEN</label>
                <select class="form-control"  id="pais" name="pais" required>
                    <option value="">Seleccione...</option>
                    <?php $__currentLoopData = $pais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pais): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($pais->id); ?>" <?php echo e(old('pais')==$pais->id ? 'selected' : ''); ?>>
                            <?php echo e($pais->pais); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
                <input type="button" name="data" class="next btn btn-info" value="Siguiente" />
        </fieldset>
        <fieldset>
            <div class="container text-center"  style="background-color: #C0F9DE; text-align: center; border-radius: 50px 50px 50px 50px">
                <h5>POBLACION VICTIMA DE CONFLICTO - SITUACION SOCIOECONOMICA</h5>
            </div>
            <hr>
            <div class="form-row">
                <div class="col-md-6 mb-3">
                    <label for="victima">POBLACION VICTIMA DEL CONFLICTO</label>
                    <select class="form-control"  id="victima" name="victima" required>
                        <option value="">Seleccione...</option>
                        <?php $__currentLoopData = $victima; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $victima): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($victima->id); ?>" <?php echo e(old('victima')==$victima->id ? 'selected' : ''); ?>>
                                <?php echo e($victima->poblacion); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="situacion">SITUACION SOCIOECONOMICA</label>
                    <select class="form-control"  id="situacion" name="situacion" required>
                        <option value="">Seleccione...</option>
                        <?php $__currentLoopData = $situacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $situacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($situacion->id); ?>" <?php echo e(old('situacion')==$situacion->id ? 'selected' : ''); ?>>
                                <?php echo e($situacion->situacionSocioeconomica); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="form-row">
                <div class="col-md-6 mb-3">
                    <label for="etnia">ETNIA</label>
                    <select class="form-control"  id="etnia" name="etnia" required>
                        <option value="">Seleccione...</option>
                        <?php $__currentLoopData = $etnia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etnia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($etnia->id); ?>" <?php echo e(old('etnia')==$etnia->id ? 'selected' : ''); ?>>
                                <?php echo e($etnia->etnia); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="estrato">ESTRATO</label>
                    <select class="form-control"  id="estrato" name="estrato" required>
                        <option value="">Seleccione...</option>
                        <?php $__currentLoopData = $estrato; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estrato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($estrato->id); ?>" <?php echo e(old('estrato')==$estrato->id ? 'selected' : ''); ?>>
                                <?php echo e($estrato->estrato); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                </div>
            <div class="form-row">
                <div class="col-md-6 mb-3">
                    <label for="Nsisben">NUMERO DE CARNET DEL SISBEN</label>
                    <input type="text" class="form-control" value="<?php echo e(old('Nsisben')); ?>" id="Nsisben" name="Nsisben" placeholder="Ingresa tu No de carnet del Sisben">
                </div>
                <div class="col-md-6 mb-3">
                    <label for="Psisben">PUNTAJE DEL SISBEN</label>
                    <input type="text" class="form-control" value="<?php echo e(old('Psisben')); ?>" id="Psisben" name="Psisben" placeholder="Ingresa tu puntaje de sisben">
                </div>
            </div>
            <br>

            <div class="container text-center"  style="background-color: #C0F9DE; text-align: center; border-radius: 50px 50px 50px 50px">
                <h5>INFORMACION DEL ACUDIENTE</h5>
            </div>
            <hr>

            <div class="form-row">
                <div class="col-md-6 mb-3">
                    <label for="nombresA">NOMBRE DE ACUDINTE</label>
                    <input type="text" class="form-control" value="<?php echo e(old('nombresA')); ?>" id="nombresA" name="nombresA" placeholder="Nombres de acudiente">
                </div>
                <div class="col-md-6 mb-3">
                    <label for="apellidosA">APELLIDOS DE ACUDIENTE</label>
                    <input type="text" class="form-control" value="<?php echo e(old('apellidosA')); ?>" id="apellidosA" name="apellidosA" placeholder="Apellidos de acudientes">
                </div>
            </div>

            <div class="form-row">
                <div class="col-md-6 mb-3">
                    <label for="celularA">CELULAR ACUDIENTE</label>
                    <input type="text" class="form-control" value="<?php echo e(old('celularA')); ?>" id="celularA" name="celularA" placeholder="Ingresa numero de celular">
                </div>
                <div class="col-md-6 mb-3">
                    <label for="correoA">CORREO DE ACUDIENTE</label>
                    <input type="email" class="form-control" value="<?php echo e(old('correoA')); ?>" id="correoA" name="correoA" placeholder="Ingresa el correo">
                </div>
            </div>

            <div class="form-row">
                <div class="col-md-6 mb-3">
                    <label for="tipoDocumentoA">TIPO DE DOCUMENTO DEL ACUDIENTE</label>
                    <select name="tipoDocumentoA" id="tipoDocumentoA" class="form-control">
                        <option value="">Seleccione</option>
                        <?php $__currentLoopData = $tipoDocumentoA; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipoDocumentoA): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($tipoDocumentoA->id); ?>" <?php echo e(old('tipoDocumentoA')==$tipoDocumentoA->id ? 'selected' : ''); ?>>
                                <?php echo e($tipoDocumentoA->tipoDocumento); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="NdocumentoA">NUMERO DE DOCUMENTO DE ACUDIENTE</label>
                    <input class="form-control" value="<?php echo e(old('NdocumentoA')); ?>" id="NdocumentoA" name="NdocumentoA" placeholder="Ingresa el numero de documento">
                </div>
            </div>

            <div class="form-row">
                <div class="col-md-6 mb-3">
                    <label for="paisOrigenA">PAIS DE ORIGEN ACUDIENTE</label>
                    <select name="paisOrigenA" id="paisOrigenA" class="form-control">
                        <option value="">Seleccione</option>
                        <?php $__currentLoopData = $paisOrigenA; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paisOrigenA): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($paisOrigenA->id); ?>" <?php echo e(old('paisOrigenA')==$paisOrigenA->id ? 'selected' : ''); ?>>
                                <?php echo e($paisOrigenA->pais); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="generoA">GENERO ACUDIENTE</label>
                    <select name="generoA" id="generoA" class="form-control">
                        <option value="">Seleccione</option>
                        <?php $__currentLoopData = $generoA; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $generoA): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($generoA->id); ?>" <?php echo e(old('generoA')==$generoA->id ? 'selected' : ''); ?>>
                                <?php echo e($generoA->genero); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="form-row">
                <div class="col-md-6 mb-3">
                    <label for="fechaNA">FECHA NACIMIENTO ACUDIENTE</label>
                    <input type="date" class="form-control" value="<?php echo e(old('fechaNA')); ?>" id="fechaNA" name="fechaNA">
                </div>
                <div class="col-md-6 mb-3">
                    <label for="departamentoNA">DEPARTAMENTO DE NACIMIENTO ACUDIENTE</label>
                    <select name="departamentoNA" id="departamentoNA" class="form-control">
                        <option value="">Seleccione</option>
                        <?php $__currentLoopData = $departamentoNA; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departamentoNA): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($departamentoNA->id); ?>" <?php echo e(old('departamentoNA')==$departamentoNA->id ? 'selected' : ''); ?>>
                                <?php echo e($departamentoNA->departamento); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="form-row">
                <div class="col-md-6 mb-3">
                    <label for="municipioNA">MUNICIPIO DE NACIMIENTO ACUDIENTE</label>
                    <select name="municipioNA" id="municipioNA" class="form-control">
                        <option value="">Seleccione</option>
                        <?php $__currentLoopData = $municipioNA; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $municipioNA): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($municipioNA->id); ?>" <?php echo e(old('municipioNA')==$municipioNA->id ? 'selected' : ''); ?>>
                                <?php echo e($municipioNA->municipio); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <br>

            <div class="container text-center"  style="background-color: #C0F9DE; text-align: center; border-radius: 50px 50px 50px 50px">
                <h5>DIRECCION  - OTRA INFORMACION DEL ACUDIENTE</h5>
            </div>
            <hr>

            <div class="form-row">
                <div class="col-md-6 mb-3">
                    <label for="direccionA">DIRECCION DE ACUDIENTE</label>
                    <input type="text" class="form-control" value="<?php echo e(old('direccionA')); ?>" id="direccionA" name="direccionA" placeholder="Escriba la direccion" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="barrioA">BARRIO ACUDIENTE</label>
                    <input type="text" class="form-control" value="<?php echo e(old('barrioA')); ?>" id="barrioA" name="barrioA" placeholder="Nombre del barrio" required>
                </div>
            </div>

            <div class="form-row">
                <div class="col-md-6 mb-3">
                    <label for="departamentoA">DEPARTAMENTO DEL ACUDIENTE</label>
                    <select name="departamentoA" id="departamentoA" class="form-control">
                        <option value="">Seleccione...</option>
                        <?php $__currentLoopData = $departamentoA; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departamentoA): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($departamentoA->id); ?>" <?php echo e(old('departamentoA')==$departamentoA->id ? 'selected' : ''); ?>>
                                <?php echo e($departamentoA->departamento); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="municipioA">MUNICIPIO ACUDIENTE</label>
                    <select name="municipioA" id="municipioA" class="form-control">
                        <option value="">Seleccione...</option>
                        <?php $__currentLoopData = $municipioA; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $municipioA): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($municipioA->id); ?>" <?php echo e(old('municipioA')==$municipioA->id ? 'selected' : ''); ?>>
                                <?php echo e($municipioA->municipio); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="form-row">
                <div class="col-md-6 mb-3">
                    <label for="zonaA">ZONA</label>
                    <select name="zonaA" id="zonaA" class="form-control">
                        <option value="">Seleccione...</option>
                        <?php $__currentLoopData = $zonaA; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zonaA): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($zonaA->id); ?>" <?php echo e(old('zonaA')==$zonaA->id ? 'selected' : ''); ?>>
                                <?php echo e($zonaA->zona); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="parentesco">PARENTESCO</label>
                    <select name="parentesco" id="parentesco" class="form-control">
                        <option value="">seleccione...</option>
                        <?php $__currentLoopData = $parentesco; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parentesco): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($parentesco->id); ?>" <?php echo e(old('parentesco')==$parentesco->id ? 'selected' : ''); ?>>
                                <?php echo e($parentesco->parentesco); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="form-row">
                <div class="col-md-6 mb-3">
                    <label for="tipoEmpleo">TIPO DE EMPLEO</label>
                    <select name="tipoEmpleo" id="tipoEmpleo" class="form-control">
                        <option value="">Seleccione...</option>
                        <?php $__currentLoopData = $tipoEmpleo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipoEmpleo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($tipoEmpleo->id); ?>" <?php echo e(old('tipoEmpleo')==$tipoEmpleo->id ? 'selected' : ''); ?>>
                            <?php echo e($tipoEmpleo->tipoEmpleo); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="ocupacion">OCUPACION</label>
                    <input type="text" class="form-control" value="<?php echo e(old('ocupacion')); ?>" id="ocupacion" name="ocupacion" placeholder="Ocupacion...">
                </div>
            </div>

            <div class="form-row">
                <div class="col-md-6 mb-3">
                    <label for="profesion">PROFESION</label>
                    <input type="text" class="form-control" value="<?php echo e(old('profesion')); ?>" id="profesion" name="profesion" placeholder="Profesion...">
                </div>
                <div class="col-md-6 mb-3">
                    <label for="convive">CONVIVES CON EL ESTUDIANTE</label>
                    <select name="convive" id="convive" class="form-control">
                        <option value="">Seleccione...</option>
                        <option value="SI" <?php echo e(old('convive')=='SI' ? 'selected' : ''); ?>>SI</option>
                        <option value="NO" <?php echo e(old('convive')=='NO' ? 'selected' : ''); ?>>No</option>
                    </select>
                </div>
            </div>

            <input type="button" name="previous" class="previous btn btn-danger" value="Previo" />
            <input type="button" name="next" class="next btn btn-info" value="Siguiente" />
            </fieldset>

            <fieldset>
            <div class="container"  style="background-color: #C0F9DE; text-align: center; border-radius: 50px 50px 50px 50px">
                <h5>OTRA INFORMACION – SISTEMA SALUD</h5>
            </div>
            <hr>

            <div class="form-row">
                <div class="col-md-6 mb-3">
                    <label for="sectorP">PROVIENE DEL SECTOR PRIVADO?</label>
                    <select class="form-control" id="sectorP"  name="sectorP" >
                        <option value="">Seleccione...</option>
                        <option value="SI" <?php echo e(old('sectorP')=='SI' ? 'selected' : ''); ?>>SI</option>
                        <option value="NO" <?php echo e(old('sectorP')=='NO' ? 'selected' : ''); ?>>NO</option>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="otroMuni">PROVIENE DE OTRO MUNICIPIO?</label>
                    <select class="form-control" id="otroMuni"  name="otroMuni" >
                        <option value="">Seleccione...</option>
                        <option value="SI" <?php echo e(old('otroMuni')=='SI' ? 'selected' : ''); ?>>SI</option>
                        <option value="NO" <?php echo e(old('otroMuni')=='NO' ? 'selected' : ''); ?>>NO</option>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label for="institucion">INSTITUCION DE DONDE PROVIENE</label>
                <input type="text" class="form-control" value="<?php echo e(old('institucion')); ?>" id="institucion" name="institucion" placeholder="Nombre de la institucion de donde proviene">
            </div>

            <div class="form-row">
                <div class="col-md-6 mb-3">
                    <label for="eps">E.P.S</label>
                    <input type="text" class="form-control" value="<?php echo e(old('eps')); ?>" id="eps" name="eps" placeholder="Nombre de la E.P.S">
                </div>
                <div class="col-md-6 mb-3">
                    <label for="ips">I.P.S</label>
                    <input type="text" class="form-control" value="<?php echo e(old('ips')); ?>" id="ips" name="ips" placeholder="Nombre de la I.P.S">
                </div>
            </div>

            <div class="form-row">
                <div class="col-md-6 mb-3">
                    <label for="tipoSangre">TIPO DE SANGRE</label>
                    <select class="form-control"  id="tipoSangre" name="tipoSangre" required>
                        <option value="">Seleccione...</option>
                        <?php $__currentLoopData = $tipoSangre; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipoSangre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($tipoSangre->id); ?>" <?php echo e(old('tipoSangre')==$tipoSangre->id ? 'selected' : ''); ?>>
                                <?php echo e($tipoSangre->tipoSangre); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="discapacidad">DISCAPACIDAD</label>
                    <select class="form-control"  id="discapacidad" name="discapacidad" required>
                        <option value="">Seleccione...</option>
                        <?php $__currentLoopData = $discapacidad; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discapacidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($discapacidad->id); ?>" <?php echo e(old('discapacidad')==$discapacidad->id ? 'selected' : ''); ?>>
                                <?php echo e($discapacidad->discapacidad); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="form-row">
                <div class="col-md-6 mb-3">
                    <label for="transtorno">TRANSTORNOS DE APRENDIZAJE ESCOLAR </label>
                    <select class="form-control"  id="transtorno" name="transtorno" required>
                        <option value="">Seleccione...</option>
                        <?php $__currentLoopData = $transtorno; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transtorno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($transtorno->id); ?>" <?php echo e(old('transtorno')==$transtorno->id ? 'selected' : ''); ?>>
                                <?php echo e($transtorno->transtorno); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="apoyoAcademico">APOYO ACADEMICO</label>
                    <select class="form-control"  id="apoyoAcademico" name="apoyoAcademico" required>
                        <option value="">Seleccione...</option>
                        <?php $__currentLoopData = $apoyoAcademico; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apoyoAcademico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($apoyoAcademico->id); ?>" <?php echo e(old('apoyoAcademico')==$apoyoAcademico->id ? 'selected' : ''); ?>>
                                <?php echo e($apoyoAcademico->apoyoAcademico); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="form-row">
                <div class="col-md-6 mb-3">
                    <label for="capacidades">CAPACIDADES EXCEPCIONALES</label>
                    <select class="form-control"  id="capacidades" name="capacidades" required>
                        <option value="">Seleccione...</option>
                        <?php $__currentLoopData = $capacidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $capacidades): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($capacidades->id); ?>" <?php echo e(old('capacidades')==$capacidades->id ? 'selected' : ''); ?>>
                                <?php echo e($capacidades->capacidadExepcional); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <input type="button" name="previous" class="previous btn btn-danger" value="Previo" />
            <!-- Button trigger modal -->
            <button type="button" class="btn btn-success" data-toggle="modal" data-target="#exampleModal">
              Registar
            </button>

            <!-- Modal -->
            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-body">
                    <h3>Estas seguro que quieres Hacer esto?</h3>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">CANCELAR</button>
                    <button type="submit" class="btn btn-primary">ACEPTAR</button>
                  </div>
                </div>
              </div>
            </div>
            </fieldset>
    </form>
    </div>
    <hr>

    
    <script>
        var numeroDocumento = document.getElementById("numeroDocumento");
        var tipoDocumento   = document.getElementById("tipoDocumento");
        var departamentoExp = document.getElementById("departamentoExp");
        var municipioExp    = document.getElementById("municipioExp");
        var nombres         = document.getElementById("nombres");
        var apellidos       = document.getElementById("apellidos");
        var fechaN          = document.getElementById("fechaN");
        var municipioN      = document.getElementById("municipioN");
        var departamentoN   = document.getElementById("departamentoN");
        var celular         = document.getElementById("celular");
        var correo          = document.getElementById("correo");
        var direccion       = document.getElementById("direccion");
        var barrio          = document.getElementById("barrio");
        var municipioViv    = document.getElementById("municipioViv");
        var zona            = document.getElementById("zona");
        var genero          = document.getElementById("genero");
        var grado           = document.getElementById("grado");
        var sede            = document.getElementById("sede");
        var jornada         = document.getElementById("jornada");
        var pais            = document.getElementById("pais");
        var victima         = document.getElementById("victima");
        var situacion       = document.getElementById("situacion");
        var etnia           = document.getElementById("etnia");
        var estrato         = document.getElementById("estrato");
        var Nsisben         = document.getElementById("Nsisben");
        var Psisben         = document.getElementById("Psisben");
        var nombresA        = document.getElementById("nombresA");
        var apellidosA      = document.getElementById("apellidosA");
        var tipoDocumentoA  = document.getElementById("tipoDocumentoA");
        var celularA        = document.getElementById("celularA");
        var correoA         = document.getElementById("correoA");
        var NdocumentoA     = document.getElementById("NdocumentoA");
        var paisOrigenA     = document.getElementById("paisOrigenA");
        var generoA         = document.getElementById("generoA");
        var fechaNA         = document.getElementById("fechaNA");
        var departamentoNA  = document.getElementById("departamentoNA");
        var municipioNA     = document.getElementById("municipioNA");
        var direccionA      = document.getElementById("direccionA");
        var barrioA         = document.getElementById("barrioA");
        var departamentoA   = document.getElementById("departamentoA");
        var municipioA      = document.getElementById("municipioA");
        var zonaA           = document.getElementById("zonaA");
        var parentesco      = document.getElementById("parentesco");
        var tipoEmpleo      = document.getElementById("tipoEmpleo");
        var convive         = document.getElementById("convive");
        var sectorP         = document.getElementById("sectorP");
        var otroMuni        = document.getElementById("otroMuni");
        var institucion     = document.getElementById("institucion");
        var ips             = document.getElementById("ips");
        var eps             = document.getElementById("eps");
        var tipoSangre      = document.getElementById("tipoSangre");
        var discapacidad    = document.getElementById("discapacidad");
        var transtorno      = document.getElementById("transtorno");
        var apoyoAcademico  = document.getElementById("apoyoAcademico");
        var capacidades     = document.getElementById("capacidades");



        <?php if($errors->first('capacidades')): ?>
        capacidades.style.borderColor = "red"
        <?php endif; ?>

        <?php if($errors->first('apoyoAcademico')): ?>
        apoyoAcademico.style.borderColor = "red"
        <?php endif; ?>

        <?php if($errors->first('transtorno')): ?>
        transtorno.style.borderColor = "red"
        <?php endif; ?>

        <?php if($errors->first('discapacidad')): ?>
        discapacidad.style.borderColor = "red"
        <?php endif; ?>

        <?php if($errors->first('tipoSangre')): ?>
        tipoSangre.style.borderColor = "red"
        <?php endif; ?>

        <?php if($errors->first('eps')): ?>
            eps.style.borderColor = "red"
            eps.placeholder = "Este campo es Obligatorio"
        <?php endif; ?>

        <?php if($errors->first('ips')): ?>
        ips.style.borderColor = "red"
        ips.placeholder = "Este campo es Obligatorio"
        <?php endif; ?>

        <?php if($errors->first('institucion')): ?>
        institucion.style.borderColor = "red"
        institucion.placeholder = "Este campo es Obligatorio"
        <?php endif; ?>

        <?php if($errors->first('otroMuni')): ?>
        otroMuni.style.borderColor = "red"
        <?php endif; ?>

        <?php if($errors->first('sectorP')): ?>
        sectorP.style.borderColor = "red"
        <?php endif; ?>

        <?php if($errors->first('convive')): ?>
        convive.style.borderColor = "red"
        <?php endif; ?>

        <?php if($errors->first('tipoEmpleo')): ?>
        tipoEmpleo.style.borderColor = "red"
        <?php endif; ?>

        <?php if($errors->first('parentesco')): ?>
        parentesco.style.borderColor = "red"
        <?php endif; ?>

        <?php if($errors->first('zonaA')): ?>
        zonaA.style.borderColor = "red"
        <?php endif; ?>

        <?php if($errors->first('municipioA')): ?>
        municipioA.style.borderColor = "red"
        <?php endif; ?>

        <?php if($errors->first('departamentoA')): ?>
        departamentoA.style.borderColor = "red"
        <?php endif; ?>

        <?php if($errors->first('barrioA')): ?>
        barrioA.style.borderColor = "red"
        barrioA.placeholder = "Este campo es Obligatorio"
        <?php endif; ?>

        <?php if($errors->first('direccionA')): ?>
        direccionA.style.borderColor = "red"
        direccionA.placeholder = "Este campo es obligatorio"
        <?php endif; ?>

        <?php if($errors->first('municipioNA')): ?>
        municipioNA.style.borderColor  = "red"
        <?php endif; ?>

        <?php if($errors->first('departamentoNA')): ?>
        departamentoNA.style.borderColor = "red"
        <?php endif; ?>

        <?php if($errors->first('fechaNA')): ?>
        fechaNA.style.borderColor = "red"
        <?php endif; ?>

        <?php if($errors->first('generoA')): ?>
        generoA.style.borderColor = "red"
        <?php endif; ?>

        <?php if($errors->first('paisOrigenA')): ?>
        paisOrigenA.style.borderColor = "red"
        <?php endif; ?>

        <?php if($errors->first('NdocumentoA')): ?>
        NdocumentoA.style.borderColor = "red"
        NdocumentoA.placeholder = "Este campo es Obligatorio"
        <?php endif; ?>

        <?php if($errors->first('correoA')): ?>
        correoA.style.borderColor = "red"
        <?php endif; ?>

        <?php if($errors->first('celularA')): ?>
        celularA.style.borderColor = "red"
        celularA.placeholder = "Este campo es Obligatorio"
        <?php endif; ?>

        <?php if($errors->first('tipoDocumentoA')): ?>
        tipoDocumentoA.style.borderColor = "red"
        <?php endif; ?>

        <?php if($errors->first('apellidosA')): ?>
        apellidosA.style.borderColor = "res"
        apellidosA.placeholder = "Este campo es Obligatorio"
        <?php endif; ?>

        <?php if($errors->first('nombresA')): ?>
        nombresA.style.borderColor = "red"
        nombresA.placeholder = "Este campo es Obligatorio"
        <?php endif; ?>

        <?php if($errors->first('Psisben')): ?>
        Psisben.style.borderColor = "red"
        Psisben.placeholder = "Este campo es Obligatorio"
        <?php endif; ?>

        <?php if($errors->first('Nsisben')): ?>
        Nsisben.style.borderColor = "red"
        Nsisben.placeholder = "Este campo es Obligatorio"
        <?php endif; ?>

        <?php if($errors->first('estrato')): ?>
        estrato.style.borderColor = "red"
        <?php endif; ?>

        <?php if($errors->first('etnia')): ?>
        etnia.style.borderColor = "red"
        <?php endif; ?>

        <?php if($errors->first('situacion')): ?>
        situacion.style.borderColor = "red"
        <?php endif; ?>

        <?php if($errors->first('victima')): ?>
        victima.style.borderColor = "red"
        <?php endif; ?>

        <?php if($errors->first('pais')): ?>
        pais.style.borderColor = "red"
        <?php endif; ?>

        <?php if($errors->first('jornada')): ?>
        jornada.style.borderColor = "red"
        <?php endif; ?>

        <?php if($errors->first('sede')): ?>
        sede.style.borderColor = "red"
        <?php endif; ?>

        <?php if($errors->first('grado')): ?>
        grado.style.borderColor = "red"
        <?php endif; ?>

        <?php if($errors->first('genero')): ?>
        genero.style.borderColor = "red"
        <?php endif; ?>

        <?php if($errors->first('zona')): ?>
        zona.style.borderColor = "red"
        <?php endif; ?>

        <?php if($errors->first('correo')): ?>
            correo.style.borderColor = "red"
        <?php endif; ?>

        <?php if($errors->first('municipioViv')): ?>
        municipioViv.style.borderColor = "red"
        <?php endif; ?>

        <?php if($errors->first('barrio')): ?>
        barrio.style.borderColor = "red"
        barrio.placeholder = "Este campo es obligatorio"
        <?php endif; ?>

        <?php if($errors->first('direccion')): ?>
        direccion.style.borderColor = "red"
        direccion.placeholder = "Este campo es obligatorio"
        <?php endif; ?>

        <?php if($errors->first('numeroDocumento')): ?>
            numeroDocumento.style.borderColor = "red"
            numeroDocumento.placeholder = "Este campo es obligatorio"
        <?php endif; ?>

        <?php if($errors->first('tipoDocumento')): ?>
            tipoDocumento.style.borderColor = "red"
        <?php endif; ?>

        <?php if($errors->first('departamentoExp')): ?>
            departamentoExp.style.borderColor = "red"
        <?php endif; ?>

        <?php if($errors->first('municipioExp')): ?>
            municipioExp.style.borderColor = "red"
        <?php endif; ?>

        <?php if($errors->first('nombres')): ?>
            nombres.style.borderColor = "red"
            nombres.placeholder = "Este campo es obligatorio"
        <?php endif; ?>

        <?php if($errors->first('apellidos')): ?>
            apellidos.style.borderColor = "red"
            apellidos.placeholder = "Este campo es obligatorio"
        <?php endif; ?>

        <?php if($errors->first('fechaN')): ?>
            fechaN.style.borderColor = "red"
        <?php endif; ?>

        <?php if($errors->first('municipioN')): ?>
            municipioN.style.borderColor = "red"
        <?php endif; ?>

        <?php if($errors->first('departamentoN')): ?>
            departamentoN.style.borderColor = "red"
        <?php endif; ?>

        <?php if($errors->first('celular')): ?>
            celular.style.borderColor = "red"
            celular.placeholder = "Este campo es obligatorio"
        <?php endif; ?>

    </script>

    
    <script type="text/javascript">
    $(document).ready(function(){
       var current = 1,current_step,next_step,steps;
       steps = $("fieldset").length;
       $(".next").click(function(){
           current_step = $(this).parent();
           next_step = $(this).parent().next();
           next_step.show();
           current_step.hide();
           setProgressBar(++current);
       });
       $(".previous").click(function(){
           current_step = $(this).parent();
           next_step = $(this).parent().prev();
           next_step.show();
           current_step.hide();
           setProgressBar(--current);
       });
       setProgressBar(current);
       // Change progress bar action
       function setProgressBar(curStep){
           var percent = parseFloat(100 / steps) * curStep;
           percent = percent.toFixed();
           $(".progress-bar")
               .css("width",percent+"%")
               .html(percent+"%");
       }
    });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyecto\estudiantes\resources\views/inscripcion.blade.php ENDPATH**/ ?>