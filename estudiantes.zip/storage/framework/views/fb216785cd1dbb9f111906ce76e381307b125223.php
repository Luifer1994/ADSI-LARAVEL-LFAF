<?php echo $__env->yieldContent('content'); ?>
 
 <div class="container" style="text-align: center">
    <h4>INSTITUCION EDUCATIVA NUESTRA SENIORA DEL CAMEN</h4>
    <hr>
     <h5>LISTA DE ESTUDIANTES INSCRITOS</h5>
 </div>
<table class="table table-striped">
    <thead class="bg-dark text-white">
      <tr>
        <th scope="col">DOCUMENTO</th>
        <th scope="col">NOMBRES</th>
        <th scope="col">APELLIDOS</th>
        <th scope="col">CORREO</th>
      </tr>
    </thead>
    <tbody>
         <?php $__currentLoopData = $estudiantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->numeroDocumento); ?></td>
                <td><?php echo e($item->nombres); ?></td>
                <td><?php echo e($item->apellidos); ?></td>
                <td><?php echo e($item->correo); ?></td>
            </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>

<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyecto\estudiantes\resources\views/estudiantesExport.blade.php ENDPATH**/ ?>